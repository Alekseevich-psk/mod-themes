--------------------
modThemes
--------------------
Author: @Alekseevich_psk
--------------------

A basic Extra for MODx Revolution.