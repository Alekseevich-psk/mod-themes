<?php

$_lang['setting_modthemes'] = 'Тема';
$_lang['setting_modthemes_desc'] = "Доступные значения: github. Или оставьте строчку пустой.";