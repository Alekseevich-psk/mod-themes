<?php

$_lang['setting_modthemes'] = 'Theme';
$_lang['setting_modthemes_desc'] = "Available themes: 'default' or leave it empty.";